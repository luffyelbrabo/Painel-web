#!/bin/bash
chat_id=$1

TOKEN=$(cat /bin/ppweb/botpag/token-bot)

ip_server=$(cat /bin/ppweb/botpag/ip-serv-ssh)

senha_server=$(cat /bin/ppweb/botpag/senha-serv-ssh)

URL="https://api.telegram.org/bot$TOKEN/sendMessage"

#USERNAME Uso no máximo 10 caracteres - Maior que dois digitos - Não use espaço, acentos ou caracteres especiais - Não pode ficar vazio
username=$(echo $RANDOM | md5sum | head -c 9; echo;)
#PASSWORD Número no minimo 4 digitos - Não pode ficar vazio. 
password=$(echo $RANDOM | md5sum | head -c 5; echo;)
#SSHLIMITER Deve ser maior que zero - Apenas número - Não pode ficar vazio
sshlimiter=1
# DIAS Deve ser maior que zero - Deve ser apenas número - Não pode ficar vazio
dias=32

final=$(date "+%Y-%m-%d" -d "+$dias days")
gui=$(date "+%d/%m/%Y" -d "+$dias days")
pass=$(perl -e 'print crypt($ARGV[0], "password")' $password)
sshpass -p "$senha_server" ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no root@$ip_server echo "ok" 1>/dev/null 2>/dev/null
sshpass -p "$senha_server" ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no root@$ip_server << EOF
useradd -e $final -M -s /bin/false -p $pass $username >/dev/null 2>&1 &
(echo $pass;echo $pass) |passwd $username > /dev/null 2>&1
echo "$password" >/etc/SSHPlus/senha/$username
echo "$username $sshlimiter" >>/root/usuarios.db
EOF
 
curl -s -X POST $URL -d chat_id=$chat_id  -d text="
<b>CONTA PRO CRIADA COM SUCESSO!</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Usuário: $username
Senha: $password
Expira em: $gui
Limite de conexões: $sshlimiter" -d parse_mode="HTML"
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬